Using a compiler(gcc, tc) or IDE(vscode, devc++, vs, vc) to compile the the source code "HardArrangementofComputationTasks.c".

You are free to choose ANSI or C99 standard.

Execute the executable file and test it.

If failing to compile the source code, open your terminal, and use the 'sample.exe' in this folder to test the program.

Usage:
> sample [-f filename] [-q]
If there's no arguments, output will be put in a file named "output" and print it in the screen. You can delete this file as you like.

-f: Specify which file to output to. Default is "output"

-q: Be quiet. Do not print in the screen.