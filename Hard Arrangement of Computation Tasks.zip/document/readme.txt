Reading Order:
1.Read the Report
	The report are provided in the file "Hard Arrangement of Computation Tasks.pdf"
2.Read the Input data
	The files "i.in" and "i.out" records the input and output of the i th testcase for i from 1 to 10. 
	They are also provided in the report except the ones that are too long to show.